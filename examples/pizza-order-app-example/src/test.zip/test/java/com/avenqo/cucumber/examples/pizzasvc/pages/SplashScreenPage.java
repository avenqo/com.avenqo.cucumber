package com.avenqo.cucumber.examples.pizzasvc.pages;

import com.avenqo.beapp.pages.IPage;


public interface SplashScreenPage extends IPage {
}
