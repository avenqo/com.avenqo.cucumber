package com.avenqo.cucumber.examples.pizzasvc.pages;

import com.avenqo.beapp.pages.IPage;


public interface BasketPage extends IPage {

    public void tryLogin();
}
