package com.avenqo.cucumber.examples.pizzasvc.pages.android;

import com.avenqo.beapp.elements.AndroidSelectorsBy;
import com.avenqo.beapp.elements.IWidgets4Android;
import com.avenqo.beapp.pages.AbstractPage;
import com.avenqo.beapp.pages.annotations.PageName;
import com.avenqo.beapp.pages.annotations.RequiredElement;
import com.avenqo.cucumber.examples.pizzasvc.pages.LoginPage;
import io.appium.java_client.AppiumDriver;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

@Component
@PageName("Login")
@Slf4j
public class LoginPage4Android extends AbstractPage implements LoginPage {

    @RequiredElement
    private static final By ROOT = AndroidSelectorsBy.classWithDescription(IWidgets4Android.VIEW, "Login");

    public LoginPage4Android(AppiumDriver driver) {
        super(driver);
    }

    @Override
    protected By rootLocator() {
        return ROOT;
    }
}
