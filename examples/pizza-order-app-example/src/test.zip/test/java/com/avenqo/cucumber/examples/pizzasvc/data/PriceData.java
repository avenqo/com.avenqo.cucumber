package com.avenqo.cucumber.examples.pizzasvc.data;

//public record PriceData (Float value, String currency){ }


public record PriceData(Float value, String currency) {

    public PriceData {
        value = normalize(value);
    }

    public PriceData(String value, String currency) {
        this(Float.parseFloat(value.replace(",", ".")), currency);
    }

    // zusätzliche Convenience-Constructors:

    public PriceData(Double value, String currency) {
        this(value.floatValue(), currency);
    }

    public PriceData(Integer value, String currency) {
        this(value.floatValue(), currency);
    }

    private static Float normalize(Object rawValue) {
        if (rawValue == null) return null;

        if (rawValue instanceof Float f) return f;
        if (rawValue instanceof Double d) return d.floatValue();
        if (rawValue instanceof Integer i) return i.floatValue();

        if (rawValue instanceof String s) {
            // Erlaubt "1,23" oder "1.23"
            String cleaned = s.trim().replace(",", ".");
            return Float.parseFloat(cleaned);
        }

        throw new IllegalArgumentException(
                "Unsupported value type: " + rawValue.getClass()
        );
    }
}