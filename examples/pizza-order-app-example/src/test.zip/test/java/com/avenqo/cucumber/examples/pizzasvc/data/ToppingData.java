package com.avenqo.cucumber.examples.pizzasvc.data;

public record ToppingData(String name, PriceData price) {
}
