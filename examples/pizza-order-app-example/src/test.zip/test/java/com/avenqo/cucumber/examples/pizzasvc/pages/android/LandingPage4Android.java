package com.avenqo.cucumber.examples.pizzasvc.pages.android;

import com.avenqo.beapp.pages.AbstractPage;
import com.avenqo.beapp.pages.annotations.PageName;
import com.avenqo.beapp.pages.annotations.RequiredElement;
import com.avenqo.beapp.pages.annotations.RequiredForComplete;
import com.avenqo.cucumber.examples.pizzasvc.data.PizzaData;
import com.avenqo.cucumber.examples.pizzasvc.pages.LandingPage;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;


@PageName("Landing")
@Slf4j
public class LandingPage4Android extends AbstractPage implements LandingPage {

    private static final By ROOT = By.id("landing_root");

    @RequiredElement
    @RequiredForComplete
    private final By byPizzaList = AppiumBy.accessibilityId("pizza_list_item");
    private final By title = By.xpath("//android.widget.TextView[@text='Landing']");
    private final By pizzaList = By.id("landing_pizza_list"); // nur als Beispiel

    public LandingPage4Android(AppiumDriver driver) {
        super(driver);
    }

    @Override
    protected By rootLocator() {
        return ROOT;
    }


    public List<PizzaData> getVisiblePizzas() {
        log.info("");
        List<WebElement> tiles =
                driver.findElements(byPizzaList);

        List<PizzaData> result = new ArrayList<>();

        for (WebElement tile : tiles) {
            List<WebElement> texts =
                    tile.findElements(AppiumBy.className("android.widget.TextView"));

            String name = texts.size() > 0 ? texts.get(0).getText() : "";
            String description = texts.size() > 1 ? texts.get(1).getText() : "";
            result.add(new PizzaData(name, description, null));
        }
        return result;
    }

    public void selectPizza(String name) {
        log.info("name [{}]");
        WebElement element = driver.findElement(AppiumBy.accessibilityId(name));
        element.click();
    }
}
