package com.avenqo.cucumber.examples.pizzasvc.config;

import com.avenqo.beapp.config.BeAppFrameworkConfig;
import com.avenqo.cucumber.examples.pizzasvc.pages.LandingPage;
import com.avenqo.cucumber.examples.pizzasvc.pages.SplashScreenPage;
import com.avenqo.cucumber.examples.pizzasvc.pages.android.LandingPage4Android;
import com.avenqo.cucumber.examples.pizzasvc.pages.android.SplashScreenPage4Android;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@ComponentScan(basePackages = {
        "com.avenqo.cucumber.examples.pizzasvc"
})
@Import(BeAppFrameworkConfig.class)
public class CucumberSpringConfig4Pizza {

    @Bean
    public SplashScreenPage splashScreen(AppiumDriver driver) {
        String platform = String.valueOf(
                driver.getCapabilities().getCapability(CapabilityType.PLATFORM_NAME)
        );

        if ("android".equalsIgnoreCase(platform)) {
            return new SplashScreenPage4Android(driver);
        } else if ("ios".equalsIgnoreCase(platform)) {
            return null;//new IosBasketPage(driver);
        }

        throw new IllegalStateException("Unsupported platform: " + platform);
    }

    @Bean
    public LandingPage landingPage(AppiumDriver driver) {
        String platform = String.valueOf(
                driver.getCapabilities().getCapability(CapabilityType.PLATFORM_NAME)
        );

        if ("android".equalsIgnoreCase(platform)) {
            return new LandingPage4Android(driver);
        } else if ("ios".equalsIgnoreCase(platform)) {
            return null;//new IosBasketPage(driver);
        }

        throw new IllegalStateException("Unsupported platform: " + platform);
    }
}
