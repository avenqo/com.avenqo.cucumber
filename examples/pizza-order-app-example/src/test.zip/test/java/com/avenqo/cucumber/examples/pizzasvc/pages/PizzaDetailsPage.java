package com.avenqo.cucumber.examples.pizzasvc.pages;

import com.avenqo.beapp.pages.IPage;
import com.avenqo.cucumber.examples.pizzasvc.data.PriceData;
import com.avenqo.cucumber.examples.pizzasvc.data.SelectableToppingData;

import java.util.Map;


public interface PizzaDetailsPage extends IPage {

    public Map<String, SelectableToppingData> getVisibleToppings();


    public boolean isToppingVisible(SelectableToppingData expectedTopping);


    public int getIndexOfToppingByName(String topping);

    public void selectToppingByIndex(int index) throws Throwable;

    public PriceData getPrice();

    public void add2Basket();

    public void goToBasket();
}
