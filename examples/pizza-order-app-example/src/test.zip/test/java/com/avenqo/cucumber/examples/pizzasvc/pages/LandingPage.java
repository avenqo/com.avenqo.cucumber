package com.avenqo.cucumber.examples.pizzasvc.pages;

import com.avenqo.beapp.pages.IPage;
import com.avenqo.cucumber.examples.pizzasvc.data.PizzaData;

import java.util.List;


public interface LandingPage extends IPage {

    public boolean isComplete();

    public List<PizzaData> getVisiblePizzas();

    public void selectPizza(String name);
}
