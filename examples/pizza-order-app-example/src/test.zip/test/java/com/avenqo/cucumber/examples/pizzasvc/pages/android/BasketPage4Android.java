package com.avenqo.cucumber.examples.pizzasvc.pages.android;

import com.avenqo.beapp.elements.AndroidSelectorsBy;
import com.avenqo.beapp.elements.IWidgets4Android;
import com.avenqo.beapp.pages.AbstractPage;
import com.avenqo.beapp.pages.annotations.PageName;
import com.avenqo.beapp.pages.annotations.RequiredElement;
import com.avenqo.cucumber.examples.pizzasvc.pages.BasketPage;
import io.appium.java_client.AppiumDriver;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.stereotype.Component;

import java.time.Duration;

@Component
@PageName("Basket")
@Slf4j
public class BasketPage4Android extends AbstractPage implements BasketPage {

    @RequiredElement
    private static final By ROOT = AndroidSelectorsBy.classWithDescription(IWidgets4Android.VIEW, "Warenkorb");

    public BasketPage4Android(AppiumDriver driver) {
        super(driver);
    }

    @Override
    protected By rootLocator() {
        return ROOT;
    }

    public void tryLogin() {
        log.info("");
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.invisibilityOfElementLocated(
                        AndroidSelectorsBy.classWithDescription(IWidgets4Android.VIEW, "Zur Bestellung hinzugefügt.")
                ));

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));
        WebElement button = wait.until(
                ExpectedConditions.elementToBeClickable(AndroidSelectorsBy.classWithDescription(IWidgets4Android.BUTTON, "Login, um zu bestellen")
                )
        );
        button.click();
    }
}
