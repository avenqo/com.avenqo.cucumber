package com.avenqo.cucumber.examples.pizzasvc.pages.ios;

import com.avenqo.beapp.pages.AbstractPage;
import com.avenqo.beapp.pages.annotations.PageName;
import com.avenqo.beapp.pages.annotations.RequiredElement;
import com.avenqo.cucumber.examples.pizzasvc.pages.SplashScreenPage;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.cucumber.spring.ScenarioScope;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

@Component
@ScenarioScope
@PageName("Splash Screen")
@Slf4j
public class SplashScreenPage4Ios extends AbstractPage implements SplashScreenPage {

    @RequiredElement
    private final By splashImage = AppiumBy.accessibilityId("splash_screen_image");

    public SplashScreenPage4Ios(AppiumDriver driver) {
        super(driver);
    }

    @Override
    protected By rootLocator() {
        return splashImage; // falls Splash sichtbarkeit auf genau diesem Element basiert
    }
}
